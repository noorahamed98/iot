const express = require("express");
const bodyParser = require("body-parser");
const { exec } = require("child_process");
const fs = require("fs");
const path = require("path");
const util = require("util");
const AWS = require("aws-sdk");
const execPromise = util.promisify(exec);

const app = express();
const PORT = 80;

app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static("public"));
app.use(express.json());
app.use("/certs", express.static(path.join(__dirname, "certs")));

const historyFile = path.join(__dirname, "history.json");
const usersFile = path.join(__dirname, "users.json");

AWS.config.update({ region: "ap-south-1" });
const iot = new AWS.Iot();

const basePrefixes = {
  IOTIQBM_1: "IoTIQbm1",
  IOTIQBM_2: "IoTIQbm2",
  IOTIQBM_3: "IoTIQbm3",
  ACSBM: "IoTIQbmA"
};

const tankPrefixes = {
  FUNNELBM_1: "funnelbm1",
  FUNNELBM_2: "funnelbm2",
  FUNNELBM_3: "funnelbm3"
};

function generateHeaderFile(thingName, certDir) {
  const certPath = path.join(certDir, "certificate.pem.crt");
  const keyPath = path.join(certDir, "private.pem.key");
  const caPath = path.join(certDir, "AmazonRootCA1.pem");

  if (!fs.existsSync(certPath) || !fs.existsSync(keyPath) || !fs.existsSync(caPath)) {
    throw new Error(`Missing certificate files for ${thingName}`);
  }

  const toRaw = (str) => `R\"EOF(\n${str}\n)EOF\"`;

  const cert = fs.readFileSync(certPath, "utf8");
  const key = fs.readFileSync(keyPath, "utf8");
  const ca = fs.readFileSync(caPath, "utf8");

  const headerContent = `
#ifndef ${thingName.toUpperCase()}_H
#define ${thingName.toUpperCase()}_H

const char* DEVICE_CERT = ${toRaw(cert)};
const char* DEVICE_KEY  = ${toRaw(key)};
const char* AWS_ROOT_CA = ${toRaw(ca)};

#endif // ${thingName.toUpperCase()}_H
`.trim();

  const headerPath = path.join(__dirname, "certs", `${thingName}.h`);

  fs.writeFileSync(headerPath, headerContent);

  return headerPath;
}

function listThingsByPrefix(prefix) {
  return new Promise((resolve, reject) => {
    exec("aws iot list-things", (err, stdout) => {
      if (err) return reject(err);
      try {
        const data = JSON.parse(stdout);
        const matching = data.things
          .map(t => t.thingName)
          .filter(name => name.startsWith(prefix));
        resolve(matching);
      } catch (e) {
        reject(e);
      }
    });
  });
}

app.get("/api/history", async (req, res) => {
  if (!fs.existsSync(historyFile)) return res.json([]);
  const history = JSON.parse(fs.readFileSync(historyFile));
  const verified = [];

  for (const entry of history) {
    try {
      await iot.describeThing({ thingName: entry.name }).promise();
      verified.push(entry);
    } catch (e) {
      // Thing not found
    }
  }
  fs.writeFileSync(historyFile, JSON.stringify(verified, null, 2));
  res.json(verified);
});

app.post("/api/next-range", async (req, res) => {
  const { type, baseModel, tankModel, count } = req.body;

  if (!type || !count || (type === "Base" && !baseModel) || (type === "Tank" && !tankModel)) {
    return res.status(400).json({ error: "Invalid input" });
  }

  const prefix = type === "Tank" ? tankPrefixes[tankModel] : basePrefixes[baseModel];
  const now = new Date();
  const dateCode = `${String(now.getMonth() + 1).padStart(2, "0")}${String(now.getFullYear()).slice(-2)}`;

  try {
    const things = await listThingsByPrefix(`${prefix}${dateCode}A`);
    const maxId = things.reduce((max, thing) => {
      const match = thing.match(/A(\d{3})$/);
      const num = match ? parseInt(match[1]) : 0;
      return Math.max(max, num);
    }, 0);

    const start = maxId + 1;
    const end = start + count - 1;

    const pad = (n) => n.toString().padStart(3, "0");
    const startId = `${prefix}${dateCode}A${pad(start)}`;
    const endId = `${prefix}${dateCode}A${pad(end)}`;

    res.json({ range: `${startId} to ${endId}` });
  } catch (e) {
    console.error("Error generating next range:", e);
    res.status(500).json({ error: "Internal error" });
  }
});

app.post("/create", async (req, res) => {
  const { type, baseModel, tankModel, count, user } = req.body;
  if (!type || !count || (type === "Base" && !baseModel) || (type === "Tank" && !tankModel)) {
    return res.status(400).send("Invalid input");
  }

  const prefix = type === "Tank" ? tankPrefixes[tankModel] : basePrefixes[baseModel];
  const now = new Date();
  const dateCode = `${String(now.getMonth() + 1).padStart(2, "0")}${String(now.getFullYear()).slice(-2)}`;

  try {
    const things = await listThingsByPrefix(`${prefix}${dateCode}A`);
    const maxId = things.reduce((max, thing) => {
      const match = thing.match(/A(\d{3})$/);
      const num = match ? parseInt(match[1]) : 0;
      return Math.max(max, num);
    }, 0);

    const pad = (n) => n.toString().padStart(3, "0");
    const newThings = [];
    for (let i = 1; i <= count; i++) {
      const id = maxId + i;
      const thingName = `${prefix}${dateCode}A${pad(id)}`;
      newThings.push(thingName);
    }

    await Promise.all(
      newThings.map(async name => {
        const model = baseModel || tankModel || "";
        console.log(`Creating Thing: ${name}`);
        await execPromise(`bash ./create-iot-thing.sh ${name} ${type} ${model}`);
        const certDir = path.join(__dirname, "certs", name);
        generateHeaderFile(name, certDir);
      })
    );

    const history = fs.existsSync(historyFile) ? JSON.parse(fs.readFileSync(historyFile)) : [];
    const newHistory = newThings.map(name => ({
      name,
      createdAt: new Date().toISOString(),
      user: user || "Unknown"
    }));

    fs.writeFileSync(historyFile, JSON.stringify([...history, ...newHistory], null, 2));
    const createdList = newThings.map(n => `<li>${n}</li>`).join("");
    res.send(`✅ Success!<br/>Created: ${count} thing(s)<ul>${createdList}</ul>`);
  } catch (err) {
    console.error("Create error:", err);
    res.status(500).send("Error creating one or more things.");
  }
});

app.post("/delete", async (req, res) => {
  const { thingName } = req.body;
  if (!thingName) return res.status(400).send("Missing thing name");

  try {
    await execPromise(`bash ./delete-iot-thing.sh ${thingName}`);
    const history = fs.existsSync(historyFile) ? JSON.parse(fs.readFileSync(historyFile)) : [];
    const updated = history.filter(d => d.name !== thingName);
    fs.writeFileSync(historyFile, JSON.stringify(updated, null, 2));

    const certDir = path.join(__dirname, "certs", thingName);
    fs.rmSync(certDir, { recursive: true, force: true });

    res.send(`✅ Successfully Deleted ${thingName}`);
  } catch (err) {
    console.error("Delete error:", err);
    res.status(500).send("Error deleting the thing.");
  }
});

app.post("/register", (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).send("Missing credentials");
  const users = fs.existsSync(usersFile) ? JSON.parse(fs.readFileSync(usersFile)) : [];
  if (users.find(u => u.username === username)) {
    return res.status(409).send("User already exists");
  }
  users.push({ username, password });
  fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));
  res.send("✅ Registered successfully");
});

app.post("/login", (req, res) => {
  const { username, password } = req.body;
  const users = fs.existsSync(usersFile) ? JSON.parse(fs.readFileSync(usersFile)) : [];
  const user = users.find(u => u.username === username && u.password === password);
  if (user) {
    res.send("✅ Login successful");
  } else {
    res.status(401).send("Invalid username or password");
  }
});

app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});
