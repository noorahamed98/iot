const express = require("express");
const bodyParser = require("body-parser");
const { exec } = require("child_process");
const app = express();
const PORT = 3000;

app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static("public"));

app.post("/create", (req, res) => {
  const thingName = req.body.thingName;
  if (!thingName) return res.send("Thing name is required.");

  exec(`bash ./create-iot-thing.sh ${thingName}`, (error, stdout, stderr) => {
    if (error) {
      console.error(stderr);
      return res.send(`<pre>❌ Error:\n${stderr}</pre>`);
    }
    res.send(`<pre>✅ Success:\n${stdout}</pre>`);
  });
});

app.listen(PORT, () => {
  console.log(`🚀 IoT UI running at http://localhost:${PORT}`);
});
