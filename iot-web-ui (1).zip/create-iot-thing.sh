#!/bin/bash

THING_NAME="$1"

if [ -z "$THING_NAME" ]; then
  echo "❌ Please provide a thing name."
  exit 1
fi

CERT_DIR="./certs/$THING_NAME"
mkdir -p "$CERT_DIR"

aws iot create-keys-and-certificate --set-as-active --output json > "$CERT_DIR/tmp_cert.json"

jq -r .certificatePem "$CERT_DIR/tmp_cert.json" > "$CERT_DIR/certificate.pem.crt"
jq -r .keyPair.PrivateKey "$CERT_DIR/tmp_cert.json" > "$CERT_DIR/private.pem.key"
jq -r .keyPair.PublicKey "$CERT_DIR/tmp_cert.json" > "$CERT_DIR/public.pem.key"
curl -s -o "$CERT_DIR/AmazonRootCA1.pem" https://www.amazontrust.com/repository/AmazonRootCA1.pem

CERT_ARN=$(jq -r .certificateArn "$CERT_DIR/tmp_cert.json")

aws iot create-thing --thing-name "$THING_NAME"
aws iot attach-thing-principal --thing-name "$THING_NAME" --principal "$CERT_ARN"

rm "$CERT_DIR/tmp_cert.json"
echo "✅ Created Thing and downloaded certificates in $CERT_DIR"
