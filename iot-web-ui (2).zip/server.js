
const express = require('express');
const fs = require('fs');
const path = require('path');
const AWS = require('aws-sdk');
const bodyParser = require('body-parser');
const axios = require('axios');

AWS.config.update({ region: 'ap-northeast-3' });

const app = express();
app.use(bodyParser.json());
app.use(express.static('public'));

const iot = new AWS.Iot();
const CERTS_BASE_DIR = path.join(__dirname, 'certs');
const LOG_FILE = path.join(__dirname, 'things_log.csv');
const POLICY_NAME = 'IoTThingPolicy';

if (!fs.existsSync(CERTS_BASE_DIR)) {
  fs.mkdirSync(CERTS_BASE_DIR);
}

if (!fs.existsSync(LOG_FILE)) {
  fs.writeFileSync(LOG_FILE, "thingName,certId,certArn,createdAt\n");
}

app.post('/create-thing', async (req, res) => {
  const { thingName } = req.body;
  const certDir = path.join(CERTS_BASE_DIR, thingName);

  if (!thingName) return res.status(400).send("Thing name required");

  if (fs.existsSync(certDir)) {
    return res.status(409).send("Thing already exists");
  }

  fs.mkdirSync(certDir, { recursive: true });

  try {
    await iot.createThing({ thingName }).promise();

    const certResp = await iot.createKeysAndCertificate({ setAsActive: true }).promise();
    const { certificatePem, keyPair, certificateArn, certificateId } = certResp;

    fs.writeFileSync(`${certDir}/certificate.pem`, certificatePem);
    fs.writeFileSync(`${certDir}/private.key`, keyPair.PrivateKey);
    fs.writeFileSync(`${certDir}/public.key`, keyPair.PublicKey);

    const ca = await axios.get('https://www.amazontrust.com/repository/AmazonRootCA1.pem');
    fs.writeFileSync(`${certDir}/AmazonRootCA1.pem`, ca.data);

    await iot.attachThingPrincipal({
      thingName,
      principal: certificateArn
    }).promise();

    const policies = await iot.listPolicies({}).promise();
    const exists = policies.policies.some(p => p.policyName === POLICY_NAME);

    if (!exists) {
      await iot.createPolicy({
        policyName: POLICY_NAME,
        policyDocument: JSON.stringify({
          Version: "2012-10-17",
          Statement: [{
            Effect: "Allow",
            Action: ["iot:*"],
            Resource: ["*"]
          }]
        })
      }).promise();
    }

    await iot.attachPolicy({
      policyName: POLICY_NAME,
      target: certificateArn
    }).promise();

    const logLine = `${thingName},${certificateId},${certificateArn},${new Date().toISOString()}\n`;
    fs.appendFileSync(LOG_FILE, logLine);

    res.send({ message: "✅ Thing created", folder: `/certs/${thingName}` });
  } catch (err) {
    console.error("❌ Error:", err);
    res.status(500).send("Failed to create Thing");
  }
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
